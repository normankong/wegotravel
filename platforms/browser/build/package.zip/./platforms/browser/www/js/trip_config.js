var tripsConfig = 
{
	tripList : [
				{	
					id       : "201605",
					name     : "Okinawa 2016",
					package  : "okinawa.zip",
					config   : "cdvfile://localhost/sdcard/hailey/trip/okinawa/config.json",
					rel      : ""
				},
				{	
					id       : "201609",
					name     : "Kyushu 2016",
					package  : "kyushu.zip" ,
					config   : "cdvfile://localhost/sdcard/hailey/trip/kyushu/config.json",
					rel      : ""
				}
			   ]
};