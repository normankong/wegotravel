var tripConfig = 
{
	title : "Fukuoka 2016",
	pageList : [
				{id : "1001"		, name : "Overview"	, imageUrl : "cdvfile://localhost/sdcard/hailey/kyushu/2016 Kyushu-page-001.jpg"},
				{id : "1002"		, name : "Ticket"	, imageUrl : "cdvfile://localhost/sdcard/hailey/kyushu/2016 Kyushu-page-002.jpg"},
				{id : "1003"		, name : "Bus"		, imageUrl : "cdvfile://localhost/sdcard/hailey/kyushu/2016 Kyushu-page-003.jpg"},
				{id : "1004"		, name : "Train"	, imageUrl : "cdvfile://localhost/sdcard/hailey/kyushu/2016 Kyushu-page-004.jpg"},
				{id : "1005"		, name : "Hotel"	, imageUrl : "cdvfile://localhost/sdcard/hailey/kyushu/2016 Kyushu-page-005.jpg"},
				{id : "1006"		, name : "Food"		, imageUrl : "cdvfile://localhost/sdcard/hailey/kyushu/2016 Kyushu-page-006.jpg"}
			]
};