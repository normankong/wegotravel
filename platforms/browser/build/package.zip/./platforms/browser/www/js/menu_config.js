var leftMenuConfig = 
{
	pageList: [
				{id : "1001"		, href : "javascript:app.refreshTrips()"					, name : "Refresh Trips", rel : ""}
			]
};

var rightMenuConfig = 
{
	pageList: [
				{id : "1001"		, href : "javascript:app.takePhoto()"						, name : "Take Photo    ", rel : "close"},
				{id : "1001"		, href : "#"												, name : "Shares        ", rel : "close"},
				{id : "1001"		, href : "javascript:app.browse('http://www.google.com')"	, name : "Google Search ", rel : "close"},
				{id : "1001"		, href : "javascript:app.browse('http://map.google.com')"	, name : "Google Map    ", rel : "close"},
				{id : "1001"		, href : "javascript:app.refreshApp()"						, name : "Download      ", rel : "close"},
				{id : "1002"		, href : "javascript:app.downloadZip()"						, name : "Download Zip  ", rel : "close"},
				{id : "1003"		, href : "javascript:app.showDebug()"						, name : "Show Debug    ", rel : "close"}
			]
};